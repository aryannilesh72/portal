 <?php echo form_open(base_url() . 'index.php/AdminDashboard/get_emp_details/'); ?>
 <div class = "container">
 <h4 class = "text-center">Add Salary Slip</h4>
 	<div class = "panel panel-default" style = "padding:20px;">
 
<div class="row">

    <div class="col-md-3">
        <div class="form-group">
            <h5>Select Department<span style="color: #cc0000">*</span></h5>
					<select required="" name="dept_id" class="form-control">
							<?php
						$department_list = $this->db->get('department')->result_array();
					foreach ($department_list  as $val): ?>
			<option value="<?php echo $val['dept_id']; ?>">
				<?php echo $val['dept_name']; ?></option>
					<?php endforeach; ?>
				   </select>

        </div>
	</div>
              <div class="col-md-3">
           <div class="form-group">
            <h5>Select Location<span style="color: #cc0000">*</span></h5>
					<select required="" name="loc_id" class="form-control" >
							<?php
						$location_list = $this->db->get('location')->result_array();
					foreach ($location_list  as $val): ?>
			<option value="<?php echo $val['loc_id']; ?>">
				<?php echo $val['loc_name']; ?></option>
					<?php endforeach; ?>
				   </select>

        </div>
    </div>
    
       <div class="col-md-3">
           <div class="form-group">
            <h5>Select Designation<span style="color: #cc0000">*</span></h5>
					<select required="" name="desig_id" class="form-control" >
							<?php
						$desig_list = $this->db->get('designation')->result_array();
					foreach ($desig_list  as $val): ?>
			<option value="<?php echo $val['desig_id']; ?>">
				<?php echo $val['desig_name']; ?></option>
					<?php endforeach; ?>
				   </select>

        </div>
    </div>
     <div class="col-md-3">
           <div class="form-group">
            <h5>Select Emplyoee<span style="color: #cc0000">*</span></h5>
					<select required="" name="user_id" class="form-control" >
							<?php
						$user_list = $this->db->get('employees')->result_array();
					foreach ($user_list  as $val): ?>
			<option value="<?php echo $val['user_id']; ?>">
				<?php echo $val['username']; ?></option>
					<?php endforeach; ?>
				   </select>

        </div>
    </div>
    
     <div class="row">
			<div class="col-lg-8 input_field_sections">
							<button type="submit" class="btn btn-primary">Add Salary</button>
					       </div>
                </div>
		</div></div></div>
    
   <?php form_close(); ?>
 